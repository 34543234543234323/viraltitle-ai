import { useState, useEffect } from 'react';
import { Sparkles, Copy, RefreshCw, TrendingUp, Hash, Target, Award, Clock } from 'lucide-react';
import { cn } from './utils/cn';

interface GeneratedContent {
  titles: string[];
  description: string;
  keywords: string[];
  hashtags: string[];
  seoScore: number;
  viralScore: number;
}

const trendingTopics = [
  "AI Agents", "Faceless YouTube", "Passive Income", 
  "ChatGPT 5", "No Code AI", "Remote Work 2025", "Bitcoin ETF",
  "Web3 Gaming", "Mental Health", "Side Hustle Ideas"
];

const platforms = ['YouTube', 'Instagram', 'TikTok', 'Blog', 'LinkedIn', 'Twitter'];
const tones = ['Professional', 'Casual', 'Exciting', 'Educational', 'Storytelling', 'Controversial'];

const titleHooks = [
  "The Ultimate Guide to",
  "Why Everyone is Talking About",
  "How I Made $10k With",
  "10 Secrets of",
  "Beginner to Pro in",
  "The Dark Truth About",
  "You Need to Know This About",
  "2025's Best",
  "This Changed Everything",
  "Stop Making These Mistakes in"
];

function generateTitles(topic: string, platform: string): string[] {
  const titles: string[] = [];
  const hooks = [...titleHooks].sort(() => Math.random() - 0.5).slice(0, 6);
  
  hooks.forEach(hook => {
    let title = `${hook} ${topic}`;
    if (platform === 'YouTube' || platform === 'TikTok') {
      title += ` | Must Watch`;
    } else if (platform === 'Instagram') {
      title += ` ✨`;
    }
    titles.push(title);
  });
  
  // Add some variations
  titles.push(`How to Master ${topic} in Under 30 Days`);
  titles.push(`${topic}: The Complete 2025 Breakdown`);
  
  return titles.slice(0, 8);
}

function generateDescription(topic: string, platform: string, tone: string): string {
  const intro = `Discover everything you need to know about ${topic.toLowerCase()}. `;
  let body = '';
  
  if (tone === 'Educational') {
    body = `In this comprehensive guide, we'll explore proven strategies, real world examples, and expert tips that will help you succeed. Whether you're just starting out or looking to scale, these insights will transform how you approach ${topic.toLowerCase()}.`;
  } else if (tone === 'Exciting') {
    body = `🚀 This is the ONE thing that will completely change the game for you! From mind-blowing tips to insider secrets that 99% of people don't know about.`;
  } else {
    body = `Learn the strategies that top creators use to get massive results with ${topic.toLowerCase()}. This video/article will give you the exact blueprint you need to replicate their success.`;
  }
  
  const cta = `\n\n👉 Like, comment, and subscribe for more tips like this!\n\nWhat did you think? Drop your thoughts below 👇`;
  
  let desc = intro + body + cta;
  
  if (platform === 'YouTube' || platform === 'TikTok') {
    desc += `\n\nTimestamps:\n00:00 Intro\n01:20 The Big Problem\n03:45 Solution Revealed`;
  }
  
  return desc.trim();
}

function generateKeywords(topic: string): string[] {
  const base = topic.toLowerCase().split(' ').filter(w => w.length > 2);
  const keywords = [
    topic,
    ...base.map(w => w + ' tips'),
    ...base.map(w => w + ' tutorial'),
    'how to ' + topic.toLowerCase(),
    topic.toLowerCase() + ' 2025',
    'best ' + topic.toLowerCase(),
  ];
  return [...new Set(keywords)].slice(0, 12);
}

function generateHashtags(topic: string): string[] {
  const words = topic.toLowerCase().split(/\s+/);
  const hashtags = [
    '#Viral', '#Trending', '#FYP', '#ForYou', '#LearnOnTikTok',
    '#' + words[0] + 'Tok', '#' + topic.replace(/\s/g, ''),
    '#ContentCreator', '#DigitalMarketing', '#GrowthHacking',
  ];
  
  words.forEach(word => {
    if (word.length > 3) hashtags.push('#' + word.charAt(0).toUpperCase() + word.slice(1));
  });
  
  return [...new Set(hashtags)].slice(0, 15);
}

async function fetchRealTrends(source: 'Reddit' | 'HackerNews' | 'Mixed' = 'Reddit', platform?: string): Promise<string[]> {
  try {
    if (source === 'HackerNews' || source === 'Mixed') {
      // Hacker News API - Free & Real-time
      const storiesRes = await fetch('https://hacker-news.firebaseio.com/v0/topstories.json');
      const storyIds = await storiesRes.json();
      
      const topIds = storyIds.slice(0, 12);
      const storyPromises = topIds.map((id: number) =>
        fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`).then(res => res.json())
      );
      
      const stories = await Promise.all(storyPromises);
      
      const hnTitles = stories
        .filter(story => story && story.title)
        .map(story => story.title)
        .filter(title => !title.includes('Show HN') && title.length < 70);

      if (source === 'HackerNews') {
        return hnTitles.slice(0, 12);
      }
      
      // For Mixed, we'll combine with Reddit below
      if (source === 'Mixed') {
        const redditTrends = await fetchRedditTrends(platform || 'popular');
        return [...hnTitles.slice(0, 6), ...redditTrends.slice(0, 6)];
      }
    }
    
    // Default Reddit
    return await fetchRedditTrends(platform || 'popular');
  } catch (error) {
    console.error('Failed to fetch trends:', error);
    return [
      "AI Agents 2025", "Faceless YouTube Channels", "Passive Income Strategies",
      "ChatGPT Advanced Prompts", "No Code AI Tools", "Remote Work Trends",
      "Quantum Computing", "Web3 Revolution", "Creator Economy"
    ];
  }
}

async function fetchRedditTrends(subredditOrPlatform: string): Promise<string[]> {
  let subreddit = 'popular';
  
  if (['YouTube', 'TikTok'].includes(subredditOrPlatform)) subreddit = 'videos';
  else if (subredditOrPlatform === 'Instagram') subreddit = 'pics';
  else if (subredditOrPlatform === 'Twitter') subreddit = 'news';
  else if (subredditOrPlatform === 'LinkedIn') subreddit = 'business';
  else if (['popular', 'all'].includes(subredditOrPlatform)) subreddit = 'popular';
  else subreddit = subredditOrPlatform;

  const response = await fetch(`https://www.reddit.com/r/${subreddit}/hot.json?limit=20`);
  const data = await response.json();
  
  if (!data.data?.children) return [];

  return data.data.children
    .map((post: any) => post.data.title)
    .filter((title: string) => 
      title.length < 75 && 
      !title.includes('http') && 
      !title.toLowerCase().includes('reddit')
    )
    .slice(0, 15)
    .map((title: string) => {
      return title
        .replace(/\[.*?\]/g, '')
        .replace(/\s*\(.*?\)\s*/g, '')
        .replace(/^\d+\.\s*/, '')
        .trim();
    });
}

export function App() {
  const [topic, setTopic] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState('YouTube');
  const [selectedSource, setSelectedSource] = useState<'Reddit' | 'HackerNews' | 'Mixed'>('Reddit');
  const [selectedTone, setSelectedTone] = useState('Exciting');
  const [isGenerating, setIsGenerating] = useState(false);
  const [content, setContent] = useState<GeneratedContent | null>(null);
  const [trends, setTrends] = useState(trendingTopics);
  const [history, setHistory] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'titles' | 'description' | 'seo'>('titles');
  const [copied, setCopied] = useState<string | null>(null);
  const [isLoadingTrends, setIsLoadingTrends] = useState(false);

  // Fetch real trends from multiple free APIs
  const loadRealTrends = async () => {
    setIsLoadingTrends(true);
    const realTrends = await fetchRealTrends(selectedSource, selectedPlatform);
    if (realTrends.length > 0) {
      setTrends(realTrends);
    }
    setIsLoadingTrends(false);
  };

  useEffect(() => {
    loadRealTrends();
  }, [selectedPlatform, selectedSource]);

  // Simulate occasional trend refresh
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.65) {
        loadRealTrends();
      }
    }, 45000);
    
    return () => clearInterval(interval);
  }, [selectedPlatform, selectedSource]);

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    
    setIsGenerating(true);
    
    // Simulate API thinking time
    await new Promise(resolve => setTimeout(resolve, 1350));
    
    const titles = generateTitles(topic, selectedPlatform);
    const description = generateDescription(topic, selectedPlatform, selectedTone);
    const keywords = generateKeywords(topic);
    const hashtags = generateHashtags(topic);
    
    const newContent: GeneratedContent = {
      titles,
      description,
      keywords,
      hashtags,
      seoScore: Math.floor(Math.random() * 18) + 82,
      viralScore: Math.floor(Math.random() * 25) + 75,
    };
    
    setContent(newContent);
    setHistory(prev => [topic, ...prev].slice(0, 5));
    setActiveTab('titles');
    
    setIsGenerating(false);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  const copyAll = () => {
    if (!content) return;
    
    const allText = `Titles:\n${content.titles.join('\n')}\n\nDescription:\n${content.description}\n\nKeywords: ${content.keywords.join(', ')}\n\nHashtags: ${content.hashtags.join(' ')}`;
    
    navigator.clipboard.writeText(allText);
    setCopied('all');
    setTimeout(() => setCopied(null), 2000);
  };

  const useTrend = (trend: string) => {
    setTopic(trend);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      {/* Navbar */}
      <nav className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-lg fixed w-full z-50">
        <div className="max-w-screen-2xl mx-auto px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-x-3">
            <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <div className="font-bold text-3xl tracking-tighter">viral<span className="text-violet-400">title</span></div>
              <div className="text-[10px] text-zinc-500 -mt-1">AI POWERED</div>
            </div>
          </div>
          
          <div className="flex items-center gap-x-8 text-sm">
            <div className="flex items-center gap-x-2 text-emerald-400 text-xs px-3 py-1.5 bg-emerald-950 rounded-full border border-emerald-900">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
              MULTIPLE FREE APIS
            </div>
            <div className="flex gap-x-6 text-zinc-400">
              <a href="#" className="hover:text-white transition-colors">Templates</a>
              <a href="#" className="hover:text-white transition-colors">Blog</a>
              <a href="#" className="hover:text-white transition-colors">Pricing</a>
            </div>
          </div>
          
          <div className="flex items-center gap-x-3">
            <div className="text-xs px-4 py-2 rounded-3xl border border-zinc-700 flex items-center gap-x-2 hover:bg-white/5 transition-colors cursor-pointer">
              <Clock className="h-4 w-4" /> 24.8k generated today
            </div>
          </div>
        </div>
      </nav>

      <div className="flex pt-20 max-w-screen-2xl mx-auto">
        {/* Left Sidebar - Controls */}
        <div className="w-80 border-r border-zinc-800 bg-zinc-950 p-8 flex-shrink-0">
          <div className="mb-8">
            <div className="flex items-center gap-x-2 mb-3">
              <Target className="h-5 w-5 text-violet-400" />
              <h2 className="uppercase text-xs tracking-[2px] font-mono text-zinc-400">CONTENT BRIEF</h2>
            </div>
            
            <div className="space-y-6">
              {/* Topic Input */}
              <div>
                <label className="text-xs uppercase font-medium text-zinc-400 block mb-2">YOUR TOPIC OR KEYWORD</label>
                <textarea 
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full h-28 bg-zinc-900 border border-zinc-700 rounded-3xl px-5 py-4 text-sm resize-none focus:outline-none focus:border-violet-500 placeholder:text-zinc-500"
                  placeholder="e.g. Faceless YouTube automation..."
                />
              </div>

              {/* Platform */}
              <div>
                <label className="text-xs uppercase font-medium text-zinc-400 block mb-2">PLATFORM</label>
                <div className="grid grid-cols-3 gap-2">
                  {platforms.map((plat) => (
                    <button
                      key={plat}
                      onClick={() => setSelectedPlatform(plat)}
                      className={cn(
                        "py-2 text-xs font-medium rounded-2xl transition-all border",
                        selectedPlatform === plat 
                          ? "bg-white text-zinc-900 border-white" 
                          : "bg-zinc-900 border-zinc-700 hover:border-zinc-600"
                      )}
                    >
                      {plat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Data Source - Multiple Free APIs */}
              <div>
                <label className="text-xs uppercase font-medium text-zinc-400 block mb-2 flex items-center gap-2">
                  <span>DATA SOURCE</span>
                  <span className="text-[10px] bg-emerald-900 text-emerald-400 px-2 py-0.5 rounded">FREE APIs</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Reddit', 'HackerNews', 'Mixed'] as const).map((source) => (
                    <button
                      key={source}
                      onClick={() => setSelectedSource(source)}
                      className={cn(
                        "py-2 text-xs font-medium rounded-2xl transition-all border text-center",
                        selectedSource === source 
                          ? "bg-violet-600 text-white border-violet-500" 
                          : "bg-zinc-900 border-zinc-700 hover:border-zinc-600"
                      )}
                    >
                      {source === 'HackerNews' ? 'HackerN' : source}
                    </button>
                  ))}
                </div>
                <div className="text-[10px] text-emerald-500 mt-1.5">
                  {selectedSource === 'Reddit' && '• Live from Reddit Hot'}
                  {selectedSource === 'HackerNews' && '• Live from Hacker News'}
                  {selectedSource === 'Mixed' && '• Reddit + Hacker News'}
                </div>
              </div>

              {/* Tone */}
              <div>
                <label className="text-xs uppercase font-medium text-zinc-400 block mb-2">TONE / STYLE</label>
                <select 
                  value={selectedTone}
                  onChange={(e) => setSelectedTone(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-3xl px-5 py-3 text-sm focus:outline-none focus:border-violet-500"
                >
                  {tones.map(tone => (
                    <option key={tone} value={tone}>{tone}</option>
                  ))}
                </select>
              </div>

              <button 
                onClick={handleGenerate}
                disabled={isGenerating || !topic.trim()}
                className={cn(
                  "w-full h-14 rounded-3xl text-base font-semibold flex items-center justify-center gap-x-3 transition-all active:scale-[0.985]",
                  isGenerating 
                    ? "bg-zinc-700 text-white cursor-wait" 
                    : "bg-white text-zinc-900 hover:bg-amber-200"
                )}
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="h-5 w-5 animate-spin" />
                    GENERATING WITH AI...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-5 w-5" />
                    GENERATE VIRAL CONTENT
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick History */}
          {history.length > 0 && (
            <div className="mt-8">
              <div className="text-xs uppercase font-medium text-zinc-400 mb-3">RECENT TOPICS</div>
              <div className="space-y-1">
                {history.map((pastTopic, index) => (
                  <div 
                    key={index}
                    onClick={() => setTopic(pastTopic)}
                    className="text-sm px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 rounded-2xl cursor-pointer transition-colors text-zinc-300 line-clamp-1"
                  >
                    {pastTopic}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Main Content Area */}
        <div className="flex-1 p-8">
          {!content ? (
            /* Empty State */
            <div className="flex flex-col items-center justify-center h-[calc(100vh-160px)] text-center">
              <div className="mb-6 h-16 w-16 rounded-full bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 flex items-center justify-center">
                <Sparkles className="h-9 w-9 text-violet-400" />
              </div>
              <h1 className="text-5xl font-semibold tracking-tighter mb-3">Create Viral Titles &amp; Descriptions</h1>
              <p className="max-w-md text-zinc-400 text-lg">Enter a topic above and our AI will instantly generate high-converting titles, SEO-rich descriptions, trending keywords and viral hashtags.</p>
              
              <div className="mt-16 grid grid-cols-3 gap-4 max-w-md">
                {['YouTube Thumbnails', 'Clickbait-Free', 'Trending SEO'].map((benefit, i) => (
                  <div key={i} className="bg-zinc-900 rounded-3xl px-5 py-6 text-center text-xs border border-zinc-800">
                    {benefit}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-8">
                <div>
                  <div className="flex items-center gap-x-3">
                    <div className="text-emerald-400">
                      <Award className="h-6 w-6" />
                    </div>
                    <div>
                      <div className="font-semibold text-3xl tracking-tight">{topic}</div>
                      <div className="text-zinc-500 text-sm">Generated just now • {selectedPlatform}</div>
                    </div>
                  </div>
                </div>
                
                <button 
                  onClick={copyAll}
                  className="flex items-center gap-x-2 bg-white/5 hover:bg-white/10 transition-colors text-sm px-5 h-9 rounded-2xl border border-white/10"
                >
                  <Copy className="h-4 w-4" />
                  {copied === 'all' ? 'COPIED!' : 'COPY ALL'}
                </button>
              </div>

              {/* Score indicators */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-5 flex gap-5 items-center">
                  <div className="flex-1">
                    <div className="text-xs text-amber-400 tracking-widest">SEO SCORE</div>
                    <div className="text-6xl font-semibold tabular-nums text-white">{content.seoScore}</div>
                    <div className="text-xs text-zinc-500">out of 100</div>
                  </div>
                  <div className="h-14 w-px bg-zinc-700"></div>
                  <div className="text-xs leading-tight text-zinc-400">
                    Excellent keyword usage<br /> 
                    Strong meta potential<br />
                    High search relevance
                  </div>
                </div>
                
                <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-5 flex gap-5 items-center">
                  <div className="flex-1">
                    <div className="text-xs text-rose-400 tracking-widest">VIRAL POTENTIAL</div>
                    <div className="text-6xl font-semibold tabular-nums text-white">{content.viralScore}</div>
                    <div className="text-xs text-zinc-500">out of 100</div>
                  </div>
                  <div className="h-14 w-px bg-zinc-700"></div>
                  <div className="text-xs leading-tight text-zinc-400">
                    Strong hooks detected<br /> 
                    High shareability<br />
                    Emotional triggers
                  </div>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-zinc-800 mb-6">
                {[
                  { id: 'titles', label: 'HEADLINES', icon: Sparkles },
                  { id: 'description', label: 'DESCRIPTION', icon: Target },
                  { id: 'seo', label: 'KEYWORDS & TAGS', icon: Hash }
                ].map(tab => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={cn(
                        "px-8 py-4 text-sm flex items-center gap-x-2 border-b-2 transition-colors",
                        activeTab === tab.id 
                          ? "border-white text-white" 
                          : "border-transparent text-zinc-400 hover:text-zinc-200"
                      )}
                    >
                      <Icon className="h-4 w-4" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>

              {/* TAB CONTENT */}
              {activeTab === 'titles' && (
                <div className="space-y-3">
                  <div className="text-xs text-zinc-400 mb-4 flex items-center gap-x-2">
                    <div className="h-px flex-1 bg-zinc-800"></div>
                    CLICK ANY TITLE TO COPY
                    <div className="h-px flex-1 bg-zinc-800"></div>
                  </div>
                  
                  {content.titles.map((title, index) => (
                    <div 
                      key={index}
                      onClick={() => copyToClipboard(title, `title-${index}`)}
                      className="group bg-zinc-900 hover:bg-zinc-800/70 border border-zinc-700 hover:border-violet-500/30 px-7 py-6 rounded-3xl flex justify-between items-start cursor-pointer transition-all"
                    >
                      <div className="text-[17px] leading-tight pr-8">{title}</div>
                      <div className={cn(
                        "text-xs px-4 py-2 rounded-2xl border flex-shrink-0 mt-0.5 transition-colors",
                        copied === `title-${index}` 
                          ? "bg-emerald-950 border-emerald-600 text-emerald-400" 
                          : "border-zinc-700 group-hover:border-zinc-500"
                      )}>
                        {copied === `title-${index}` ? '✓ COPIED' : 'COPY'}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'description' && content && (
                <div className="bg-zinc-900 border border-zinc-700 rounded-3xl p-8">
                  <div className="uppercase text-xs tracking-widest mb-4 text-zinc-400">FULL DESCRIPTION</div>
                  <div className="whitespace-pre-wrap text-[15px] leading-relaxed text-zinc-200 font-light">
                    {content.description}
                  </div>
                  
                  <button 
                    onClick={() => copyToClipboard(content.description, 'description')}
                    className="mt-8 flex items-center gap-x-2 text-sm hover:text-white text-zinc-400"
                  >
                    <Copy className="h-4 w-4" /> 
                    {copied === 'description' ? 'COPIED TO CLIPBOARD ✓' : 'COPY DESCRIPTION'}
                  </button>
                </div>
              )}

              {activeTab === 'seo' && (
                <div className="grid grid-cols-2 gap-6">
                  {/* Keywords */}
                  <div className="bg-zinc-900 rounded-3xl p-8 border border-zinc-700">
                    <div className="flex items-center gap-x-2 mb-6">
                      <Target className="h-5 w-5 text-amber-300" />
                      <div className="uppercase text-xs tracking-[1px]">HIGH-VALUE KEYWORDS</div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      {content.keywords.map((kw, i) => (
                        <div key={i} className="bg-zinc-800 text-xs border border-zinc-600 px-5 py-2 rounded-3xl">{kw}</div>
                      ))}
                    </div>
                    
                    <div className="mt-8 pt-8 border-t border-zinc-700 text-xs">
                      <div className="font-mono text-emerald-400 mb-2">LSI KEYWORDS RECOMMENDED</div>
                      <div className="text-zinc-400">Use these keywords naturally in your content to rank higher in search engines.</div>
                    </div>
                  </div>

                  {/* Hashtags */}
                  <div className="bg-zinc-900 rounded-3xl p-8 border border-zinc-700">
                    <div className="flex justify-between mb-6">
                      <div className="flex items-center gap-x-2">
                        <Hash className="h-5 w-5 text-fuchsia-400" />
                        <div className="uppercase text-xs tracking-[1px]">VIRAL HASHTAGS</div>
                      </div>
                      <div className="text-[10px] bg-fuchsia-950 text-fuchsia-400 px-3 rounded py-1">15 RECOMMENDED</div>
                    </div>
                    
                    <div className="flex flex-wrap gap-x-2 gap-y-3 text-sm">
                      {content.hashtags.map((tag, index) => (
                        <span 
                          key={index} 
                          onClick={() => copyToClipboard(tag, `hashtag-${index}`)}
                          className="cursor-pointer hover:text-violet-300 transition-colors px-4 py-1 bg-zinc-800 rounded-3xl border border-transparent hover:border-violet-400/30"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    
                    <button 
                      onClick={() => copyToClipboard(content.hashtags.join(' '), 'hashtags')}
                      className="mt-8 text-xs flex items-center gap-2 text-zinc-400 hover:text-white"
                    >
                      <Copy className="h-3.5 w-3.5" /> COPY ALL HASHTAGS
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Sidebar - Live Trends */}
        <div className="w-72 bg-zinc-900 border-l border-zinc-800 p-6 flex-shrink-0">
          <div className="flex items-center justify-between mb-6 sticky top-6">
            <div className="flex items-center gap-x-3">
              <TrendingUp className="h-4 w-4 text-orange-400" />
              <div>
                <div className="font-medium text-sm">LIVE TRENDS</div>
                <div className="text-[10px] text-emerald-400">
                  {selectedSource === 'Reddit' && 'FROM REDDIT'}
                  {selectedSource === 'HackerNews' && 'FROM HACKER NEWS'}
                  {selectedSource === 'Mixed' && 'MULTI-SOURCE'}
                  {' • REAL-TIME'}
                </div>
              </div>
            </div>
            
            <button 
              onClick={loadRealTrends}
              disabled={isLoadingTrends}
              className="text-zinc-400 hover:text-white disabled:opacity-50 transition-colors"
            >
              <RefreshCw className={`h-4 w-4 ${isLoadingTrends ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <div className="space-y-2">
            {isLoadingTrends ? (
              <div className="flex items-center justify-center py-12 text-zinc-500">
                <RefreshCw className="h-5 w-5 animate-spin mr-2" />
                Fetching live trends...
              </div>
            ) : (
              trends.map((trend, index) => (
                <div 
                  key={index}
                  onClick={() => useTrend(trend)}
                  className="group px-5 py-4 bg-zinc-950 hover:bg-zinc-800 border border-transparent hover:border-orange-900 rounded-3xl cursor-pointer transition-all text-sm flex items-center gap-3"
                >
                  <span className="text-orange-400 text-xl">#{index + 1}</span>
                  <span className="flex-1 line-clamp-2 text-zinc-300 group-hover:text-white transition-colors">{trend}</span>
                </div>
              ))
            )}
          </div>

          <div className="mt-auto pt-8 text-[10px] text-center text-zinc-500 border-t border-zinc-800 mt-10">
            Click any trend to instantly use it as your topic
          </div>
          
          <div className="mt-8 text-xs bg-zinc-950 border border-dashed border-emerald-900 rounded-3xl p-5 text-center leading-snug text-emerald-400">
            ✅ Using FREE Public APIs<br />
            {selectedSource === 'Reddit' && '• Reddit JSON API'}<br />
            {selectedSource === 'HackerNews' && '• Hacker News Firebase API'}<br />
            {selectedSource === 'Mixed' && '• Reddit + Hacker News'}<br />
            Live trending data updated every 45 seconds
          </div>
        </div>
      </div>
    </div>
  );
}
